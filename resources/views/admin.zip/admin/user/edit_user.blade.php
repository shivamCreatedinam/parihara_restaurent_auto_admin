<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="Dashboard">
    <title>Students Profile</title>
    <!-- GOOGLE FONTS -->
    @include('admin/common/head')
</head>

<body class="ec-header-fixed ec-sidebar-fixed ec-sidebar-light ec-header-light" id="body">
    <!--  WRAPPER  -->
    <div class="wrapper">

        <!-- LEFT MAIN SIDEBAR -->
        @include('admin/common/sidebar')
        <!--  PAGE WRAPPER -->
        <div class="ec-page-wrapper">
            <!-- Header -->
            @include('admin/common/header')
            <!-- CONTENT WRAPPER -->
            <!-- CONTENT WRAPPER -->
            <div class="ec-content-wrapper">
                <div class="content">
                    <div class="breadcrumb-wrapper breadcrumb-contacts">
                        <div>
                            <h1>Students Profile</h1>
                            <p class="breadcrumbs">
                                <span><a href="{{url('sysadmin/dashboard')}}">Home</a></span>
                                <span><i class="mdi mdi-chevron-right"></i></span>Profile<span><i
                                        class="mdi mdi-chevron-right"></i><a onclick="history.back()"
                                        href="javascript:void(0)">Back</a></span>
                            </p>
                        </div>

                    </div>
                    <div class="card bg-white profile-content ec-vendor-profile">
                        <div class="row">
                            <div class="col-lg-4 col-xl-3">
                                <div class="profile-content-left profile-left-spacing">
                                    <div class="ec-disp">
                                        <div class="text-center widget-profile px-0 border-0">
                                            <div class="card-img mx-auto rounded-circle">
                                                <img src="{{asset($data->user_image)}}" alt="user image">
                                            </div>
                                            <div class="card-body">
                                                <h4 class="py-2 text-dark">{{$data->name}}</h4>
                                                <h4 class="py-2 text-dark">{{$data->user_id}}</h4>

                                            </div>
                                        </div>


                                    </div>
                                    <hr class="w-100">

                                    <div class="contact-info pt-4">
                                        <h5 class="text-dark">Contact Information</h5>
                                        <p class="text-dark font-weight-medium pt-24px mb-2">Email address</p>
                                        <p>{{$data->email}}</p>
                                        <p class="text-dark font-weight-medium pt-24px mb-2">Phone Number</p>
                                        <p>+ 91{{$data->mobile}}</p>

                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-8 col-xl-9">
                                <div class="profile-content-right profile-right-spacing py-5">
                                    <ul class="nav nav-tabs px-3 px-xl-5 nav-style-border" id="myProfileTab"
                                        role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link active" id="profile-tab" data-bs-toggle="tab"
                                                data-bs-target="#profile" type="button" role="tab"
                                                aria-controls="profile" aria-selected="true">Profile</button>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <button class="nav-link" id="settings-tab" data-bs-toggle="tab"
                                                data-bs-target="#settings" type="button" role="tab"
                                                aria-controls="settings" aria-selected="false">Payment</button>
                                        </li>
                                    </ul>
                                    <div class="tab-content px-3 px-xl-5" id="myTabContent">

                                        <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                            <div class="tab-widget mt-5">
                                                <form>
                                             
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Student`s Name</label>
                                                        <input type="text" class="form-control" id="userName"
                                                            value="{{$data->name}}" readonly>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Student Mobile</label>
                                                        <input type="text" class="form-control" id="userName"
                                                            value="{{$data->mobile}}" readonly>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Guardian Mobile</label>
                                                        <input type="text" class="form-control" id="userName"
                                                            value="{{$data->guardian_mobile}}" readonly>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Email</label>
                                                        <input type="text" class="form-control" id="userName"
                                                            value="{{$data->email}}" readonly>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Father`s Name</label>
                                                        <input type="text" class="form-control" id="userName"
                                                            value="{{$data->fathers_name}}" readonly>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Mother`s Name</label>
                                                        <input type="text" class="form-control" id="userName"
                                                            value="{{$data->mothers_name}}" readonly>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">DOB</label>
                                                        <input type="text" class="form-control" id="userName"
                                                            value="{{$data->dob}}" readonly>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Gender</label>
                                                        <select name="gender" class="form-control" readonly>
                                                            <option value="">Select One</option>
                                                            <option value="Male" <?php 
                                                            if ($data->gender == 'Male') {
                                                                echo 'selected';
                                                            }
                                                            ?>>Male</option>
                                                            <option value="Female"  <?php 
                                                            if ($data->gender == 'Female') {
                                                                echo 'selected';
                                                            }
                                                            ?>>Female</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Marital Status</label>
                                                        <select name="martial_status" class="form-control" readonly>
                                                            <option value="">Select One</option>
                                                            <option value="Married" <?php 
                                                            if ($data->martial_status == 'Married') {
                                                                echo 'selected';
                                                            }
                                                            ?>>Married</option>
                                                            <option value="Unmarried" <?php 
                                                            if ($data->martial_status == 'Unmarried') {
                                                                echo 'selected';
                                                            }
                                                            ?>>Unmarried</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Religion</label>
                                                        <select name="religion" class="form-control" readonly>
                                                            <option value="">Select One</option>
                                                            <option value="Hindu" <?php 
                                                            if ($data->religion == 'Hindu') {
                                                                echo 'selected';
                                                            }
                                                            ?>>Hindu</option>
                                                            <option value="Muslim" <?php 
                                                            if ($data->religion == 'Muslim') {
                                                                echo 'selected';
                                                            }
                                                            ?>>Muslim</option>
                                                            <option value="Sikh" <?php 
                                                            if ($data->religion == 'Sikh') {
                                                                echo 'selected';
                                                            }
                                                            ?>>Sikh</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Caste</label>
                                                        <select name="caste" class="form-control" readonly>
                                                            <option value="">Select One</option>
                                                            <option value="General" <?php 
                                                            if ($data->caste == 'General') {
                                                                echo 'selected';
                                                            }
                                                            ?>>General</option>
                                                            <option value="OBC" <?php 
                                                            if ($data->caste == 'OBC') {
                                                                echo 'selected';
                                                            }
                                                            ?>>OBC</option>
                                                            <option value="SC/ST" <?php 
                                                            if ($data->caste == 'SC/ST') {
                                                                echo 'selected';
                                                            }
                                                            ?>>SC/ST</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Nationality</label>
                                                        <select name="nationality" class="form-control" readonly>
                                                            <option value="">Select One</option>
                                                            <option value="Indian" <?php 
                                                            if ($data->nationality == 'Indian') {
                                                                echo 'selected';
                                                            }?>>Indian</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Address</label>
                                                        <textarea cols="20" class="form-control" name="address" rows="4" placeholder="Enter Address" readonly>{{$data->address}}</textarea>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Pincode</label>
                                                        <input type="text" name="pincode" class="form-control" minlength="6" mmaxlength="6" placeholder="Enter Pincode" value="{{$data->pincode}}" readonly />
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Select Course</label>
                                                        <select name="courses" class="form-control" readonly>
                                                            <option value="">Select One</option>
                                                            <option value="BCA" <?php 
                                                            if ($data->courses == 'BCA') {
                                                                echo 'selected';
                                                            }?>>CR100 - BCA</option>


                                                            <option value="MCA" <?php 
                                                            if ($data->courses == 'MCA') {
                                                                echo 'selected';
                                                            }?>>CR102 - MCA</option>
                                                            
                                                                <option value="CCC" <?php 
                                                            if ($data->courses == 'CCC') {
                                                                echo 'selected';
                                                            }?>>CR103 - CCC</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Batch Time</label>
                                                        <select name="courses" class="form-control" readonly>
                                                            <option value="">Select One</option>
                                                          

                                    <option value="07:00 am - 08:00 am" <?php 
                                                            if ($data->batch_time == '07:00 am - 08:00 am') {
                                                                echo 'selected';
                                                            }?>>07:00 am - 08:00 am</option>
                                    <option value="08:00 am - 09:00 am" <?php 
                                                            if ($data->batch_time == '08:00 am - 09:00 am') {
                                                                echo 'selected';
                                                            }?>>08:00 am - 09:00 am</option>
                                    <option value="09:00 am - 10:00 am" <?php 
                                                            if ($data->batch_time == '09:00 am - 10:00 am') {
                                                                echo 'selected';
                                                            }?>>09:00 am - 10:00 am</option>
                                    <option value="10:00 am - 11:00 am" <?php 
                                                            if ($data->batch_time == '10:00 am - 11:00 am') {
                                                                echo 'selected';
                                                            }?>>10:00 am - 11:00 am</option>
                                    <option value="11:00 am - 12:00 pm" <?php 
                                                            if ($data->batch_time == '11:00 am - 12:00 pm') {
                                                                echo 'selected';
                                                            }?>>11:00 am - 12:00 pm</option>
                                    <option value="12:00 pm - 01:00 pm" <?php 
                                                            if ($data->batch_time == '12:00 pm - 01:00 pm') {
                                                                echo 'selected';
                                                            }?>>12:00 pm - 01:00 pm</option>
                                    <option value="01:00 pm - 02:00 pm" <?php 
                                                            if ($data->batch_time == '01:00 pm - 02:00 pm') {
                                                                echo 'selected';
                                                            }?>>01:00 pm - 02:00 pm</option>
                                    <option value="03:00 pm - 04:00 pm" <?php 
                                                            if ($data->batch_time == '03:00 pm - 04:00 pm') {
                                                                echo 'selected';
                                                            }?>>03:00 pm - 04:00 pm</option>
                                    <option value="04:00 pm - 05:00 pm" <?php 
                                                            if ($data->batch_time == '04:00 pm - 05:00 pm') {
                                                                echo 'selected';
                                                            }?>>04:00 pm - 05:00 pm</option>
                                    <option value="05:00 pm - 06:00 pm"  <?php 
                                                            if ($data->batch_time == '05:00 pm - 06:00 pm') {
                                                                echo 'selected';
                                                            }?>>05:00 pm - 06:00 pm</option>
                                    <option value="06:00 pm - 07:00 pm" <?php 
                                                            if ($data->batch_time == '06:00 pm - 07:00 pm') {
                                                                echo 'selected';
                                                            }?>>06:00 pm - 07:00 pm</option>
                                                        </select>
                                                    </div>


                                                </form>
                                            </div>
                                        </div>

                                        <div class="tab-pane fade" id="settings" role="tabpanel"
                                            aria-labelledby="settings-tab">
                                            <div class="tab-pane-content mt-5">
                                                <form>

                                                    <div class="form-group mb-4">
                                                        <label for="userName">Ref. ID</label>
                                                        <input type="text" class="form-control" id="userName"
                                                            value="{{$data->paymt_ref_id}}" readonly>

                                                    </div>
                                                    <div class="form-group mb-4">
                                                        <label for="userName">Screenshot</label><br>
                                                       <a href="{{asset($data->paymt_screenshot)}}" target="_blank"><img src="{{asset($data->paymt_screenshot)}}" style="max-width:300px;max-height:300px;" /></a>

                                                    </div>
                                                   
                                                </form>
                                            </div>
											
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div> <!-- End Content -->
            </div> <!-- End Content Wrapper -->

            @include('admin/common/footer')
            <script type="text/javascript">
            function PreviewImage() {
                var oFReader = new FileReader();
                oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);
                oFReader.onload = function(oFREvent) {
                    $('#uploadPreview').show();
                    document.getElementById("uploadPreview").src = oFREvent.target.result;

                };
            };
            </script>