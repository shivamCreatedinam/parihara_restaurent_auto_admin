<div class="ec-left-sidebar ec-bg-sidebar">
			<div id="sidebar" class="sidebar ec-sidebar-footer">

				<div class="ec-brand">
					<a href="{{url('sysadmin/dashboard')}}" title="PARIHARA">
                         
						 <img class="ec-brand-icon" src="{{asset('admin/assets/img/logo/ec-site-logo.png')}} " style="height: 72px;" alt="" /> 
						
					</a>
				</div>

				<!-- begin sidebar scrollbar -->
				<div class="ec-navigation" data-simplebar>
					<!-- sidebar menu -->
					<ul class="nav sidebar-inner" id="sidebar-menu">
						<!-- Dashboard -->
						<li class="active">
							<a class="sidenav-item-link" href="{{url('sysadmin/dashboard')}}">
								<i class="mdi mdi-view-dashboard-outline"></i>
								<span class="nav-text">Dashboard</span>
							</a>
							<hr>
						</li>



						<li class="has-sub">
							<a class="sidenav-item-link" href="{{url('sysadmin/slider-list')}}">
								<i class="mdi mdi-dns-outline"></i>
								<span class="nav-text">Home Manager</span> <b class="caret"></b>
							</a>
							
						</li>
					
					
						<!-- Users -->
						<li class="has-sub">
							<a class="sidenav-item-link" href="{{url('sysadmin/query')}}">
								<i class="mdi mdi-headphones"></i>
								<span class="nav-text">Contact Queries</span> <b class="caret"></b>
							</a>
							
							<hr>
						</li>
                        <!-- Category -->

					</ul>
				</div>
			</div>
		</div>